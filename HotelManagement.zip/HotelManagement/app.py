import streamlit as st
import pandas as pd
from datetime import date, datetime
from database import get_connection, execute_query, execute_non_query

# Page configuration
st.set_page_config(
    page_title="Hotel Management System",
    page_icon="H",
    layout="wide"
)

# Initialize session state for messages
if 'message' not in st.session_state:
    st.session_state.message = None
if 'message_type' not in st.session_state:
    st.session_state.message_type = None

# Function to show and clear messages
def show_message():
    if st.session_state.message:
        if st.session_state.message_type == 'success':
            st.success(st.session_state.message)
        elif st.session_state.message_type == 'error':
            st.error(st.session_state.message)
        st.session_state.message = None
        st.session_state.message_type = None

# Custom CSS for consistent styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1E3A5F;
        text-align: center;
        padding: 1rem 0;
        border-bottom: 2px solid #1E3A5F;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #2C5282;
        padding: 0.5rem 0;
        margin-top: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# Main header
st.markdown('<div class="main-header">Hotel Management System</div>', unsafe_allow_html=True)

# Sidebar navigation
st.sidebar.title("Navigation")
page = st.sidebar.selectbox(
    "Select Module",
    ["Dashboard", "Guests", "Rooms", "Bookings", "Services", "Staff", "Tasks", 
     "Maintenance", "Discounts", "Payments", "Feedback", "Reports"]
)

# ============================================================
# HELPER FUNCTION: Get Available Rooms for Date Range
# ============================================================
def get_available_rooms(check_in, check_out, exclude_booking_id=None):
    """Get rooms that are not booked for the given date range"""
    query = """
        SELECT r.Room_Number, r.Room_Type, r.Price, r.Capacity
        FROM ROOM r
        WHERE r.Status != 'Maintenance'
        AND r.Status != 'OutOfService'
        AND r.Room_Number NOT IN (
            SELECT rba.Room_Number 
            FROM ROOM_BOOKING_ASSIGNMENT rba
            JOIN BOOKING b ON rba.Booking_ID = b.Booking_ID
            WHERE b.Status IN ('Confirmed', 'CheckedIn')
            AND NOT (? >= rba.EndDate OR ? <= rba.StartDate)
    """
    if exclude_booking_id:
        query += f" AND rba.Booking_ID != {exclude_booking_id}"
    query += ") ORDER BY r.Room_Number"
    
    return execute_query(query, (check_out, check_in))

# ============================================================
# DASHBOARD
# ============================================================
if page == "Dashboard":
    st.markdown('<div class="section-header">Dashboard Overview</div>', unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM GUEST")
        total_guests = cursor.fetchone()[0]
        col1.metric("Total Guests", total_guests)
        
        cursor.execute("SELECT COUNT(*) FROM ROOM")
        total_rooms = cursor.fetchone()[0]
        col2.metric("Total Rooms", total_rooms)
        
        cursor.execute("SELECT COUNT(*) FROM BOOKING WHERE Status IN ('Confirmed', 'CheckedIn')")
        active_bookings = cursor.fetchone()[0]
        col3.metric("Active Bookings", active_bookings)
        
        cursor.execute("""
            SELECT COUNT(*) FROM ROOM r
            WHERE r.Status NOT IN ('Maintenance', 'OutOfService')
            AND r.Room_Number NOT IN (
                SELECT rba.Room_Number FROM ROOM_BOOKING_ASSIGNMENT rba
                JOIN BOOKING b ON rba.Booking_ID = b.Booking_ID
                WHERE b.Status IN ('Confirmed', 'CheckedIn')
                AND CAST(GETDATE() AS DATE) BETWEEN rba.StartDate AND rba.EndDate
            )
        """)
        available_rooms = cursor.fetchone()[0]
        col4.metric("Available Today", available_rooms)
        
        conn.close()
        
        # Second row of metrics
        col5, col6, col7, col8 = st.columns(4)
        
        pending_tasks = execute_query("SELECT COUNT(*) as cnt FROM TASK WHERE Status = 'Pending'")
        col5.metric("Pending Tasks", pending_tasks[0]['cnt'] if pending_tasks else 0)
        
        pending_maintenance = execute_query("SELECT COUNT(*) as cnt FROM MAINTENANCE_REQUEST WHERE Status IN ('Pending', 'InProgress')")
        col6.metric("Open Maintenance", pending_maintenance[0]['cnt'] if pending_maintenance else 0)
        
        active_staff = execute_query("SELECT COUNT(*) as cnt FROM STAFF WHERE Status = 'Active'")
        col7.metric("Active Staff", active_staff[0]['cnt'] if active_staff else 0)
        
        todays_checkouts = execute_query("""
            SELECT COUNT(*) as cnt FROM BOOKING 
            WHERE Check_Out_Date = CAST(GETDATE() AS DATE) AND Status = 'CheckedIn'
        """)
        col8.metric("Today's Checkouts", todays_checkouts[0]['cnt'] if todays_checkouts else 0)
        
        st.markdown('<div class="section-header">Recent Bookings</div>', unsafe_allow_html=True)
        query = """
            SELECT TOP 5 
                b.Booking_ID,
                g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                r.Room_Number,
                b.Check_In_Date,
                b.Check_Out_Date,
                b.Status
            FROM BOOKING b
            JOIN GUEST g ON b.Guest_ID = g.Guest_ID
            JOIN ROOM_BOOKING_ASSIGNMENT rba ON b.Booking_ID = rba.Booking_ID
            JOIN ROOM r ON rba.Room_Number = r.Room_Number
            ORDER BY b.Booking_ID DESC
        """
        df = pd.DataFrame(execute_query(query))
        if not df.empty:
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.info("No bookings found.")
            
    except Exception as e:
        st.error(f"Error loading dashboard: {e}")

# ============================================================
# GUESTS MODULE
# ============================================================
elif page == "Guests":
    st.markdown('<div class="section-header">Guest Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4 = st.tabs(["View All", "Add New", "Update", "Delete"])
    
    with tab1:
        st.subheader("All Guests")
        try:
            query = """
                SELECT Guest_ID, First_Name, Last_Name, Age, Phone, Email, 
                       City, State, Country, Nationality 
                FROM GUEST 
                ORDER BY Guest_ID
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No guests found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Add New Guest")
        with st.form("add_guest_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            
            with col1:
                first_name = st.text_input("First Name *")
                last_name = st.text_input("Last Name *")
                age = st.number_input("Age *", min_value=18, max_value=120, value=18)
                phone = st.text_input("Phone")
                email = st.text_input("Email")
                nationality = st.text_input("Nationality")
            
            with col2:
                street = st.text_input("Street")
                city = st.text_input("City")
                state = st.text_input("State")
                zip_code = st.text_input("Zip Code")
                country = st.text_input("Country")
            
            submitted = st.form_submit_button("Add Guest")
            
            if submitted:
                if not first_name or not last_name:
                    st.error("First Name and Last Name are required.")
                else:
                    query = """
                        INSERT INTO GUEST 
                        (First_Name, Last_Name, Age, Street, City, State, Zip_Code, Country, Phone, Email, Nationality)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """
                    params = (first_name, last_name, age, street, city, state, zip_code, country, phone, email, nationality)
                    success, message = execute_non_query(query, params)
                    if success:
                        st.success(f"Guest '{first_name} {last_name}' added successfully!")
                    else:
                        st.error(f"Error: {message}")
    
    with tab3:
        st.subheader("Update Guest")
        try:
            guests = execute_query("SELECT Guest_ID, First_Name, Last_Name FROM GUEST ORDER BY Guest_ID")
            if guests:
                guest_options = {f"{g['First_Name']} {g['Last_Name']} (ID: {g['Guest_ID']})": g['Guest_ID'] for g in guests}
                selected = st.selectbox("Select Guest to Update", options=list(guest_options.keys()))
                
                if selected:
                    guest_id = guest_options[selected]
                    guest_data = execute_query(f"SELECT * FROM GUEST WHERE Guest_ID = {guest_id}")[0]
                    
                    with st.form("update_guest_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            new_first_name = st.text_input("First Name", value=guest_data['First_Name'])
                            new_last_name = st.text_input("Last Name", value=guest_data['Last_Name'])
                            new_age = st.number_input("Age", min_value=18, max_value=120, value=guest_data['Age'])
                            new_phone = st.text_input("Phone", value=guest_data['Phone'] or "")
                            new_email = st.text_input("Email", value=guest_data['Email'] or "")
                            new_nationality = st.text_input("Nationality", value=guest_data['Nationality'] or "")
                        
                        with col2:
                            new_street = st.text_input("Street", value=guest_data['Street'] or "")
                            new_city = st.text_input("City", value=guest_data['City'] or "")
                            new_state = st.text_input("State", value=guest_data['State'] or "")
                            new_zip = st.text_input("Zip Code", value=guest_data['Zip_Code'] or "")
                            new_country = st.text_input("Country", value=guest_data['Country'] or "")
                        
                        update_submitted = st.form_submit_button("Update Guest")
                        
                        if update_submitted:
                            query = """
                                UPDATE GUEST SET
                                    First_Name=?, Last_Name=?, Age=?, Street=?, City=?, 
                                    State=?, Zip_Code=?, Country=?, Phone=?, Email=?, Nationality=?
                                WHERE Guest_ID=?
                            """
                            params = (new_first_name, new_last_name, new_age, new_street, new_city, 
                                     new_state, new_zip, new_country, new_phone, new_email, new_nationality, guest_id)
                            success, message = execute_non_query(query, params)
                            if success:
                                st.success("Guest updated successfully!")
                            else:
                                st.error(f"Error: {message}")
            else:
                st.info("No guests available to update.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Delete Guest")
        st.warning("Guests with existing bookings cannot be deleted.")
        
        try:
            guests = execute_query("SELECT Guest_ID, First_Name, Last_Name FROM GUEST ORDER BY Guest_ID")
            if guests:
                guest_options = {f"{g['First_Name']} {g['Last_Name']} (ID: {g['Guest_ID']})": g['Guest_ID'] for g in guests}
                selected_del = st.selectbox("Select Guest to Delete", options=list(guest_options.keys()), key="del_guest")
                
                confirm = st.checkbox("I confirm I want to delete this guest")
                
                if st.button("Delete Guest", disabled=not confirm):
                    guest_id = guest_options[selected_del]
                    success, message = execute_non_query("DELETE FROM GUEST WHERE Guest_ID = ?", (guest_id,))
                    if success:
                        st.session_state.message = "Guest deleted successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No guests available to delete.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# ROOMS MODULE
# ============================================================
elif page == "Rooms":
    st.markdown('<div class="section-header">Room Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4 = st.tabs(["View All", "Add New", "Update", "Delete"])
    
    with tab1:
        st.subheader("All Rooms")
        
        col1, col2 = st.columns(2)
        with col1:
            filter_type = st.selectbox("Filter by Type", ["All", "Single", "Double", "Suite", "Deluxe"])
        with col2:
            filter_status = st.selectbox("Filter by Status", ["All", "Available", "Occupied", "Maintenance", "OutOfService"])
        
        try:
            query = "SELECT * FROM ROOM WHERE 1=1"
            if filter_type != "All":
                query += f" AND Room_Type = '{filter_type}'"
            if filter_status != "All":
                query += f" AND Status = '{filter_status}'"
            query += " ORDER BY Room_Number"
            
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No rooms found matching the criteria.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Add New Room")
        with st.form("add_room_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            
            with col1:
                room_number = st.text_input("Room Number *")
                room_type = st.selectbox("Room Type *", ["Single", "Double", "Suite", "Deluxe"])
                price = st.text_input("Price per Night *")
            
            with col2:
                status = st.selectbox("Status *", ["Available", "Occupied", "Maintenance", "OutOfService"])
                capacity = st.text_input("Capacity *")
            
            submitted = st.form_submit_button("Add Room")
            
            if submitted:
                if not room_number or not price or not capacity:
                    st.error("Please fill in all required fields.")
                else:
                    try:
                        room_num = int(room_number)
                        price_val = float(price)
                        capacity_val = int(capacity)
                        
                        query = "INSERT INTO ROOM (Room_Number, Room_Type, Status, Price, Capacity) VALUES (?, ?, ?, ?, ?)"
                        params = (room_num, room_type, status, price_val, capacity_val)
                        success, message = execute_non_query(query, params)
                        if success:
                            st.success(f"Room {room_num} added successfully!")
                        else:
                            st.error(f"Error: {message}")
                    except ValueError:
                        st.error("Please enter valid numbers for Room Number, Price, and Capacity.")
    
    with tab3:
        st.subheader("Update Room")
        try:
            rooms = execute_query("SELECT Room_Number, Room_Type, Status FROM ROOM ORDER BY Room_Number")
            if rooms:
                room_options = {f"Room {r['Room_Number']}": r['Room_Number'] for r in rooms}
                selected = st.selectbox("Select Room to Update", options=list(room_options.keys()))
                
                if selected:
                    room_number = room_options[selected]
                    room_data = execute_query(f"SELECT * FROM ROOM WHERE Room_Number = {room_number}")[0]
                    
                    with st.form("update_room_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            new_type = st.selectbox("Room Type", ["Single", "Double", "Suite", "Deluxe"],
                                                   index=["Single", "Double", "Suite", "Deluxe"].index(room_data['Room_Type']))
                            new_price = st.number_input("Price", min_value=0.01, value=float(room_data['Price']), format="%.2f")
                        
                        with col2:
                            new_status = st.selectbox("Status", ["Available", "Occupied", "Maintenance", "OutOfService"],
                                                     index=["Available", "Occupied", "Maintenance", "OutOfService"].index(room_data['Status']))
                            new_capacity = st.number_input("Capacity", min_value=1, max_value=10, value=room_data['Capacity'])
                        
                        update_submitted = st.form_submit_button("Update Room")
                        
                        if update_submitted:
                            query = "UPDATE ROOM SET Room_Type=?, Status=?, Price=?, Capacity=? WHERE Room_Number=?"
                            params = (new_type, new_status, new_price, new_capacity, room_number)
                            success, message = execute_non_query(query, params)
                            if success:
                                st.success("Room updated successfully!")
                            else:
                                st.error(f"Error: {message}")
            else:
                st.info("No rooms available to update.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Delete Room")
        st.warning("Rooms with existing bookings cannot be deleted.")
        
        try:
            rooms = execute_query("SELECT Room_Number, Room_Type FROM ROOM ORDER BY Room_Number")
            if rooms:
                room_options = {f"Room {r['Room_Number']}": r['Room_Number'] for r in rooms}
                selected_del = st.selectbox("Select Room to Delete", options=list(room_options.keys()), key="del_room")
                
                confirm = st.checkbox("I confirm I want to delete this room")
                
                if st.button("Delete Room", disabled=not confirm):
                    room_number = room_options[selected_del]
                    success, message = execute_non_query("DELETE FROM ROOM WHERE Room_Number = ?", (room_number,))
                    if success:
                        st.session_state.message = "Room deleted successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No rooms available to delete.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# BOOKINGS MODULE - FIXED DOUBLE BOOKING
# ============================================================
elif page == "Bookings":
    st.markdown('<div class="section-header">Booking Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4 = st.tabs(["View All", "Create New", "Update Status", "Cancel Booking"])
    
    with tab1:
        st.subheader("All Bookings")
        
        status_filter = st.selectbox("Filter by Status", ["All", "Confirmed", "CheckedIn", "CheckedOut", "Cancelled"])
        
        try:
            query = """
                SELECT 
                    b.Booking_ID,
                    g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                    r.Room_Number,
                    r.Room_Type,
                    b.Check_In_Date,
                    b.Check_Out_Date,
                    b.Booking_Rate,
                    b.Status
                FROM BOOKING b
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                LEFT JOIN ROOM_BOOKING_ASSIGNMENT rba ON b.Booking_ID = rba.Booking_ID
                LEFT JOIN ROOM r ON rba.Room_Number = r.Room_Number
                WHERE 1=1
            """
            if status_filter != "All":
                query += f" AND b.Status = '{status_filter}'"
            query += " ORDER BY b.Booking_ID DESC"
            
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No bookings found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Create New Booking")
        
        try:
            guests = execute_query("SELECT Guest_ID, First_Name, Last_Name FROM GUEST ORDER BY First_Name")
            
            if not guests:
                st.warning("No guests available. Please add a guest first.")
            else:
                # Date selection first to filter available rooms
                col1, col2 = st.columns(2)
                with col1:
                    check_in = st.date_input("Check-In Date *", min_value=date.today(), key="new_checkin")
                with col2:
                    check_out = st.date_input("Check-Out Date *", min_value=date.today(), key="new_checkout")
                
                if check_out <= check_in:
                    st.error("Check-out date must be after check-in date.")
                else:
                    # Get available rooms for selected dates
                    available_rooms = get_available_rooms(check_in, check_out)
                    
                    if not available_rooms:
                        st.warning("No rooms available for the selected dates. Please choose different dates.")
                    else:
                        with st.form("add_booking_form", clear_on_submit=True):
                            guest_options = {f"{g['First_Name']} {g['Last_Name']} (ID: {g['Guest_ID']})": g['Guest_ID'] for g in guests}
                            room_options = {f"Room {r['Room_Number']} - {r['Room_Type']} (${r['Price']}/night)": r for r in available_rooms}
                            
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                selected_guest = st.selectbox("Select Guest *", options=list(guest_options.keys()))
                            with col2:
                                selected_room = st.selectbox("Select Available Room *", options=list(room_options.keys()))
                            
                            st.info(f"Selected dates: {check_in} to {check_out}")
                            
                            submitted = st.form_submit_button("Create Booking")
                            
                            if submitted:
                                guest_id = guest_options[selected_guest]
                                room_info = room_options[selected_room]
                                room_number = room_info['Room_Number']
                                booking_rate = room_info['Price']
                                
                                # Double-check availability before insert
                                recheck = get_available_rooms(check_in, check_out)
                                recheck_rooms = [r['Room_Number'] for r in recheck] if recheck else []
                                
                                if room_number not in recheck_rooms:
                                    st.error("Room is no longer available. Please select another room.")
                                else:
                                    query1 = """
                                        INSERT INTO BOOKING (Guest_ID, Booking_Rate, Check_In_Date, Check_Out_Date, Status)
                                        VALUES (?, ?, ?, ?, 'Confirmed')
                                    """
                                    success1, msg1 = execute_non_query(query1, (guest_id, booking_rate, check_in, check_out))
                                    
                                    if success1:
                                        booking_id = execute_query("SELECT MAX(Booking_ID) as ID FROM BOOKING")[0]['ID']
                                        
                                        query2 = """
                                            INSERT INTO ROOM_BOOKING_ASSIGNMENT (Room_Number, Booking_ID, StartDate, EndDate)
                                            VALUES (?, ?, ?, ?)
                                        """
                                        success2, msg2 = execute_non_query(query2, (room_number, booking_id, check_in, check_out))
                                        
                                        if success2:
                                            st.session_state.message = f"Booking created successfully! Booking ID: {booking_id}"
                                            st.session_state.message_type = "success"
                                            st.rerun()
                                        else:
                                            st.error(f"Error creating room assignment: {msg2}")
                                    else:
                                        st.error(f"Error creating booking: {msg1}")
                                
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab3:
        st.subheader("Update Booking Status")
        try:
            bookings = execute_query("""
                SELECT b.Booking_ID, g.First_Name, g.Last_Name, b.Status 
                FROM BOOKING b JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                WHERE b.Status IN ('Confirmed', 'CheckedIn')
                ORDER BY b.Booking_ID DESC
            """)
            
            if bookings:
                booking_options = {f"Booking {b['Booking_ID']} - {b['First_Name']} {b['Last_Name']} ({b['Status']})": b for b in bookings}
                selected = st.selectbox("Select Booking", options=list(booking_options.keys()))
                
                if selected:
                    booking_info = booking_options[selected]
                    booking_id = booking_info['Booking_ID']
                    current_status = booking_info['Status']
                    
                    if current_status == 'Confirmed':
                        valid_statuses = ["CheckedIn", "Cancelled"]
                    elif current_status == 'CheckedIn':
                        valid_statuses = ["CheckedOut"]
                    else:
                        valid_statuses = []
                    
                    if valid_statuses:
                        new_status = st.selectbox("New Status", valid_statuses)
                        
                        if st.button("Update Status"):
                            success, message = execute_non_query(
                                "UPDATE BOOKING SET Status = ? WHERE Booking_ID = ?",
                                (new_status, booking_id)
                            )
                            if success:
                                st.session_state.message = f"Booking status updated to '{new_status}' successfully!"
                                st.session_state.message_type = "success"
                                st.rerun()
                            else:
                                st.error(f"Error: {message}")
            else:
                st.info("No active bookings available to update.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Cancel Booking")
        
        try:
            bookings = execute_query("""
                SELECT b.Booking_ID, g.First_Name, g.Last_Name
                FROM BOOKING b JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                WHERE b.Status = 'Confirmed'
                ORDER BY b.Booking_ID DESC
            """)
            
            if bookings:
                booking_options = {f"Booking {b['Booking_ID']} - {b['First_Name']} {b['Last_Name']}": b['Booking_ID'] for b in bookings}
                selected_cancel = st.selectbox("Select Booking to Cancel", options=list(booking_options.keys()), key="cancel_booking")
                
                confirm = st.checkbox("I confirm I want to cancel this booking")
                
                if st.button("Cancel Booking", disabled=not confirm):
                    booking_id = booking_options[selected_cancel]
                    success, message = execute_non_query(
                        "UPDATE BOOKING SET Status = 'Cancelled' WHERE Booking_ID = ?",
                        (booking_id,)
                    )
                    if success:
                        st.session_state.message = "Booking cancelled successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No confirmed bookings available to cancel.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# SERVICES MODULE - IMPROVED
# ============================================================
elif page == "Services":
    st.markdown('<div class="section-header">Service Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["View Services", "Add Service", "Update Service", "Delete Service", "Add to Booking", "View Transactions"])
    
    with tab1:
        st.subheader("All Services")
        try:
            df = pd.DataFrame(execute_query("SELECT * FROM SERVICE ORDER BY Category, Service_Name"))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No services found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Add New Service")
        with st.form("add_service_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            
            with col1:
                service_name = st.text_input("Service Name *")
                price = st.text_input("Price *")
            
            with col2:
                category = st.text_input("Category")
                description = st.text_area("Description")
            
            submitted = st.form_submit_button("Add Service")
            
            if submitted:
                if not service_name or not price:
                    st.error("Service name and price are required.")
                else:
                    try:
                        price_val = float(price)
                        query = "INSERT INTO SERVICE (Service_Name, Service_Description, Price, Category) VALUES (?, ?, ?, ?)"
                        success, message = execute_non_query(query, (service_name, description, price_val, category))
                        if success:
                            st.success(f"Service '{service_name}' added successfully!")
                        else:
                            st.error(f"Error: {message}")
                    except ValueError:
                        st.error("Please enter a valid number for Price.")
    
    with tab3:
        st.subheader("Update Service")
        try:
            services = execute_query("SELECT Service_ID, Service_Name, Price, Category, Service_Description FROM SERVICE ORDER BY Service_Name")
            if services:
                service_options = {f"{s['Service_Name']} (ID: {s['Service_ID']})": s for s in services}
                selected = st.selectbox("Select Service to Update", options=list(service_options.keys()))
                
                if selected:
                    service_data = service_options[selected]
                    service_id = service_data['Service_ID']
                    
                    with st.form("update_service_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            new_name = st.text_input("Service Name", value=service_data['Service_Name'])
                            new_price = st.number_input("Price", min_value=0.01, value=float(service_data['Price']), format="%.2f")
                        
                        with col2:
                            new_category = st.text_input("Category", value=service_data['Category'] or "")
                            new_description = st.text_area("Description", value=service_data['Service_Description'] or "")
                        
                        update_submitted = st.form_submit_button("Update Service")
                        
                        if update_submitted:
                            query = "UPDATE SERVICE SET Service_Name=?, Price=?, Category=?, Service_Description=? WHERE Service_ID=?"
                            params = (new_name, new_price, new_category, new_description, service_id)
                            success, message = execute_non_query(query, params)
                            if success:
                                st.success("Service updated successfully!")
                            else:
                                st.error(f"Error: {message}")
            else:
                st.info("No services available to update.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Delete Service")
        st.warning("Services with existing transactions cannot be deleted.")
        try:
            services = execute_query("SELECT Service_ID, Service_Name FROM SERVICE ORDER BY Service_Name")
            if services:
                service_options = {f"{s['Service_Name']} (ID: {s['Service_ID']})": s['Service_ID'] for s in services}
                selected_del = st.selectbox("Select Service to Delete", options=list(service_options.keys()), key="del_service")
                
                confirm = st.checkbox("I confirm I want to delete this service")
                
                if st.button("Delete Service", disabled=not confirm):
                    service_id = service_options[selected_del]
                    success, message = execute_non_query("DELETE FROM SERVICE WHERE Service_ID = ?", (service_id,))
                    if success:
                        st.session_state.message = "Service deleted successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No services available to delete.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab5:
        st.subheader("Add Service to Booking")
        st.info("Add services used by guests during their stay. Only checked-in guests can use services.")
        
        try:
            active_bookings = execute_query("""
                SELECT b.Booking_ID, g.First_Name, g.Last_Name, r.Room_Number
                FROM BOOKING b 
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                LEFT JOIN ROOM_BOOKING_ASSIGNMENT rba ON b.Booking_ID = rba.Booking_ID
                LEFT JOIN ROOM r ON rba.Room_Number = r.Room_Number
                WHERE b.Status = 'CheckedIn'
                ORDER BY b.Booking_ID DESC
            """)
            
            services = execute_query("SELECT Service_ID, Service_Name, Price FROM SERVICE ORDER BY Service_Name")
            
            if not active_bookings:
                st.warning("No checked-in guests. Services can only be added to checked-in bookings.")
            elif not services:
                st.warning("No services available. Please add services first.")
            else:
                with st.form("add_service_transaction_form", clear_on_submit=True):
                    booking_options = {f"Booking {b['Booking_ID']} - {b['First_Name']} {b['Last_Name']} (Room {b['Room_Number']})": b['Booking_ID'] for b in active_bookings}
                    service_options = {f"{s['Service_Name']} - ${s['Price']}": s for s in services}
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        selected_booking = st.selectbox("Select Booking *", options=list(booking_options.keys()))
                        selected_service = st.selectbox("Select Service *", options=list(service_options.keys()))
                    
                    with col2:
                        quantity = st.number_input("Quantity *", min_value=1, value=1)
                    
                    submitted = st.form_submit_button("Add Service to Booking")
                    
                    if submitted:
                        booking_id = booking_options[selected_booking]
                        service_info = service_options[selected_service]
                        service_id = service_info['Service_ID']
                        total_amount = float(service_info['Price']) * quantity
                        
                        query = """
                            INSERT INTO SERVICE_TRANSACTION (Booking_ID, Service_ID, Quantity, Total_Amount, Transaction_Date)
                            VALUES (?, ?, ?, ?, GETDATE())
                        """
                        success, message = execute_non_query(query, (booking_id, service_id, quantity, total_amount))
                        if success:
                            st.session_state.message = f"Service added to booking! Total: ${total_amount:.2f}"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
                            
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab6:
        st.subheader("Service Transactions")
        st.info("View and manage service transactions for bookings.")
        
        try:
            query = """
                SELECT 
                    st.Transaction_ID,
                    b.Booking_ID,
                    g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                    s.Service_Name,
                    st.Quantity,
                    st.Total_Amount,
                    st.Transaction_Date,
                    b.Status AS Booking_Status
                FROM SERVICE_TRANSACTION st
                JOIN BOOKING b ON st.Booking_ID = b.Booking_ID
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                JOIN SERVICE s ON st.Service_ID = s.Service_ID
                ORDER BY st.Transaction_Date DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                total = df['Total_Amount'].sum()
                st.info(f"Total Service Revenue: ${total:,.2f}")
                
                # Delete transaction option
                st.markdown("---")
                st.subheader("Delete Transaction")
                st.warning("Only delete transactions for correction purposes.")
                
                transactions = execute_query("""
                    SELECT st.Transaction_ID, s.Service_Name, st.Total_Amount, b.Booking_ID
                    FROM SERVICE_TRANSACTION st
                    JOIN SERVICE s ON st.Service_ID = s.Service_ID
                    JOIN BOOKING b ON st.Booking_ID = b.Booking_ID
                    WHERE b.Status = 'CheckedIn'
                """)
                
                if transactions:
                    trans_options = {f"ID {t['Transaction_ID']} - {t['Service_Name']} (${t['Total_Amount']}) - Booking {t['Booking_ID']}": t['Transaction_ID'] for t in transactions}
                    selected_trans = st.selectbox("Select Transaction to Delete", options=list(trans_options.keys()))
                    
                    confirm_del = st.checkbox("I confirm I want to delete this transaction", key="confirm_del_trans")
                    
                    if st.button("Delete Transaction", disabled=not confirm_del):
                        trans_id = trans_options[selected_trans]
                        success, message = execute_non_query("DELETE FROM SERVICE_TRANSACTION WHERE Transaction_ID = ?", (trans_id,))
                        if success:
                            st.session_state.message = "Transaction deleted successfully!"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
                else:
                    st.info("No transactions available for deletion (only active bookings).")
            else:
                st.info("No service transactions found.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# STAFF MODULE
# ============================================================
elif page == "Staff":
    st.markdown('<div class="section-header">Staff Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["View All", "Add New", "Update", "Delete", "Shifts"])
    
    with tab1:
        st.subheader("All Staff Members")
        try:
            df = pd.DataFrame(execute_query("SELECT * FROM STAFF ORDER BY Staff_ID"))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No staff members found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Add New Staff Member")
        with st.form("add_staff_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            
            with col1:
                first_name = st.text_input("First Name *")
                last_name = st.text_input("Last Name *")
            
            with col2:
                role = st.selectbox("Role *", ["Manager", "Receptionist", "Housekeeper", "Maintenance", "Chef", "Waiter", "Bellboy", "Security", "Spa Therapist"])
                status = st.selectbox("Status *", ["Active", "Inactive", "OnLeave"])
            
            submitted = st.form_submit_button("Add Staff Member")
            
            if submitted:
                if not first_name or not last_name:
                    st.error("First Name and Last Name are required.")
                else:
                    query = "INSERT INTO STAFF (First_Name, Last_Name, Role, Status) VALUES (?, ?, ?, ?)"
                    success, message = execute_non_query(query, (first_name, last_name, role, status))
                    if success:
                        st.success(f"Staff member '{first_name} {last_name}' added successfully!")
                    else:
                        st.error(f"Error: {message}")
    
    with tab3:
        st.subheader("Update Staff Member")
        try:
            staff = execute_query("SELECT Staff_ID, First_Name, Last_Name, Role, Status FROM STAFF ORDER BY Staff_ID")
            if staff:
                staff_options = {f"{s['First_Name']} {s['Last_Name']} - {s['Role']} (ID: {s['Staff_ID']})": s for s in staff}
                selected = st.selectbox("Select Staff Member", options=list(staff_options.keys()))
                
                if selected:
                    staff_data = staff_options[selected]
                    staff_id = staff_data['Staff_ID']
                    
                    with st.form("update_staff_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            new_first_name = st.text_input("First Name", value=staff_data['First_Name'])
                            new_last_name = st.text_input("Last Name", value=staff_data['Last_Name'])
                        
                        with col2:
                            roles = ["Manager", "Receptionist", "Housekeeper", "Maintenance", "Chef", "Waiter", "Bellboy", "Security", "Spa Therapist"]
                            current_role_idx = roles.index(staff_data['Role']) if staff_data['Role'] in roles else 0
                            new_role = st.selectbox("Role", roles, index=current_role_idx)
                            new_status = st.selectbox("Status", ["Active", "Inactive", "OnLeave"],
                                                     index=["Active", "Inactive", "OnLeave"].index(staff_data['Status']))
                        
                        update_submitted = st.form_submit_button("Update Staff Member")
                        
                        if update_submitted:
                            query = "UPDATE STAFF SET First_Name=?, Last_Name=?, Role=?, Status=? WHERE Staff_ID=?"
                            params = (new_first_name, new_last_name, new_role, new_status, staff_id)
                            success, message = execute_non_query(query, params)
                            if success:
                                st.success("Staff member updated successfully!")
                            else:
                                st.error(f"Error: {message}")
            else:
                st.info("No staff members available to update.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Delete Staff Member")
        st.warning("Staff members with assigned tasks or maintenance requests cannot be deleted.")
        
        try:
            staff = execute_query("SELECT Staff_ID, First_Name, Last_Name, Role FROM STAFF ORDER BY Staff_ID")
            if staff:
                staff_options = {f"{s['First_Name']} {s['Last_Name']} - {s['Role']} (ID: {s['Staff_ID']})": s['Staff_ID'] for s in staff}
                selected_del = st.selectbox("Select Staff Member to Delete", options=list(staff_options.keys()), key="del_staff")
                
                confirm = st.checkbox("I confirm I want to delete this staff member")
                
                if st.button("Delete Staff Member", disabled=not confirm):
                    staff_id = staff_options[selected_del]
                    success, message = execute_non_query("DELETE FROM STAFF WHERE Staff_ID = ?", (staff_id,))
                    if success:
                        st.session_state.message = "Staff member deleted successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No staff members available to delete.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab5:
        st.subheader("Staff Shifts")
        
        # View shifts
        st.markdown("**Current Shifts**")
        try:
            shifts_df = pd.DataFrame(execute_query("""
                SELECT sh.Shift_ID, s.First_Name + ' ' + s.Last_Name AS Staff_Name, s.Role,
                       sh.Shift_Date, sh.Start_Time, sh.End_Time, sh.Shift_Type
                FROM SHIFT sh
                JOIN STAFF s ON sh.Staff_ID = s.Staff_ID
                ORDER BY sh.Shift_Date DESC, sh.Start_Time
            """))
            if not shifts_df.empty:
                st.dataframe(shifts_df, use_container_width=True, hide_index=True)
            else:
                st.info("No shifts scheduled.")
        except Exception as e:
            st.error(f"Error loading shifts: {e}")
        
        st.markdown("---")
        st.markdown("**Add New Shift**")
        
        try:
            active_staff = execute_query("SELECT Staff_ID, First_Name, Last_Name, Role FROM STAFF WHERE Status = 'Active' ORDER BY First_Name")
            if active_staff:
                with st.form("add_shift_form", clear_on_submit=True):
                    staff_options = {f"{s['First_Name']} {s['Last_Name']} - {s['Role']}": s['Staff_ID'] for s in active_staff}
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        selected_staff = st.selectbox("Select Staff *", options=list(staff_options.keys()))
                        shift_date = st.date_input("Shift Date *")
                        shift_type = st.selectbox("Shift Type *", ["Morning", "Evening", "Night"])
                    
                    with col2:
                        if shift_type == "Morning":
                            default_start, default_end = "07:00", "15:00"
                        elif shift_type == "Evening":
                            default_start, default_end = "15:00", "23:00"
                        else:
                            default_start, default_end = "23:00", "07:00"
                        
                        start_time = st.time_input("Start Time *", value=datetime.strptime(default_start, "%H:%M").time())
                        end_time = st.time_input("End Time *", value=datetime.strptime(default_end, "%H:%M").time())
                    
                    if st.form_submit_button("Add Shift"):
                        staff_id = staff_options[selected_staff]
                        query = "INSERT INTO SHIFT (Staff_ID, Shift_Date, Start_Time, End_Time, Shift_Type) VALUES (?, ?, ?, ?, ?)"
                        success, message = execute_non_query(query, (staff_id, shift_date, start_time, end_time, shift_type))
                        if success:
                            st.session_state.message = "Shift added successfully!"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
            else:
                st.warning("No active staff members available.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# TASKS MODULE - NEW
# ============================================================
elif page == "Tasks":
    st.markdown('<div class="section-header">Task Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4 = st.tabs(["View Tasks", "Create Task", "Assign Staff", "Update Status"])
    
    with tab1:
        st.subheader("All Tasks")
        
        status_filter = st.selectbox("Filter by Status", ["All", "Pending", "InProgress", "Completed"])
        
        try:
            query = """
                SELECT 
                    t.Task_ID,
                    t.Description,
                    t.Scheduled_Time,
                    t.Status,
                    COALESCE(s.First_Name + ' ' + s.Last_Name, 'Unassigned') AS Assigned_To,
                    ta.Assigned_Date,
                    ta.Completion_Date
                FROM TASK t
                LEFT JOIN TASK_ASSIGNMENT ta ON t.Task_ID = ta.Task_ID
                LEFT JOIN STAFF s ON ta.Staff_ID = s.Staff_ID
                WHERE 1=1
            """
            if status_filter != "All":
                query += f" AND t.Status = '{status_filter}'"
            query += " ORDER BY t.Scheduled_Time DESC"
            
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No tasks found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Create New Task")
        
        with st.form("add_task_form", clear_on_submit=True):
            description = st.text_area("Task Description *")
            
            col1, col2 = st.columns(2)
            with col1:
                scheduled_date = st.date_input("Scheduled Date *")
            with col2:
                scheduled_time = st.time_input("Scheduled Time *")
            
            status = st.selectbox("Initial Status", ["Pending", "InProgress"])
            
            if st.form_submit_button("Create Task"):
                if not description:
                    st.error("Description is required.")
                else:
                    scheduled_datetime = datetime.combine(scheduled_date, scheduled_time)
                    query = "INSERT INTO TASK (Description, Scheduled_Time, Status) VALUES (?, ?, ?)"
                    success, message = execute_non_query(query, (description, scheduled_datetime, status))
                    if success:
                        st.session_state.message = "Task created successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
    
    with tab3:
        st.subheader("Assign Staff to Task")
        
        try:
            unassigned_tasks = execute_query("""
                SELECT t.Task_ID, t.Description, t.Status
                FROM TASK t
                WHERE t.Task_ID NOT IN (SELECT Task_ID FROM TASK_ASSIGNMENT)
                AND t.Status != 'Completed'
            """)
            
            active_staff = execute_query("SELECT Staff_ID, First_Name, Last_Name, Role FROM STAFF WHERE Status = 'Active'")
            
            if not unassigned_tasks:
                st.info("No unassigned tasks available.")
            elif not active_staff:
                st.warning("No active staff members available.")
            else:
                with st.form("assign_task_form", clear_on_submit=True):
                    task_options = {f"Task {t['Task_ID']}: {t['Description'][:50]}...": t['Task_ID'] for t in unassigned_tasks}
                    staff_options = {f"{s['First_Name']} {s['Last_Name']} - {s['Role']}": s['Staff_ID'] for s in active_staff}
                    
                    selected_task = st.selectbox("Select Task *", options=list(task_options.keys()))
                    selected_staff = st.selectbox("Assign to Staff *", options=list(staff_options.keys()))
                    
                    if st.form_submit_button("Assign Task"):
                        task_id = task_options[selected_task]
                        staff_id = staff_options[selected_staff]
                        
                        query = "INSERT INTO TASK_ASSIGNMENT (Task_ID, Staff_ID, Assigned_Date) VALUES (?, ?, GETDATE())"
                        success, message = execute_non_query(query, (task_id, staff_id))
                        if success:
                            st.session_state.message = "Task assigned successfully!"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
        except Exception as e:
            st.error(f"Error: {e}")
        
        # View current assignments
        st.markdown("---")
        st.markdown("**Current Task Assignments**")
        try:
            assignments_df = pd.DataFrame(execute_query("""
                SELECT ta.Task_Assignment_ID, t.Task_ID, t.Description, 
                       s.First_Name + ' ' + s.Last_Name AS Assigned_To,
                       ta.Assigned_Date, t.Status
                FROM TASK_ASSIGNMENT ta
                JOIN TASK t ON ta.Task_ID = t.Task_ID
                JOIN STAFF s ON ta.Staff_ID = s.Staff_ID
                ORDER BY ta.Assigned_Date DESC
            """))
            if not assignments_df.empty:
                st.dataframe(assignments_df, use_container_width=True, hide_index=True)
            else:
                st.info("No task assignments yet.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Update Task Status")
        
        try:
            active_tasks = execute_query("""
                SELECT t.Task_ID, t.Description, t.Status
                FROM TASK t
                WHERE t.Status != 'Completed'
            """)
            
            if active_tasks:
                task_options = {f"Task {t['Task_ID']}: {t['Description'][:50]}... ({t['Status']})": t for t in active_tasks}
                selected = st.selectbox("Select Task", options=list(task_options.keys()))
                
                if selected:
                    task_info = task_options[selected]
                    current_status = task_info['Status']
                    
                    if current_status == 'Pending':
                        new_statuses = ['InProgress', 'Completed']
                    else:
                        new_statuses = ['Completed']
                    
                    new_status = st.selectbox("New Status", new_statuses)
                    
                    if st.button("Update Task Status"):
                        task_id = task_info['Task_ID']
                        
                        # Update task status
                        success, message = execute_non_query(
                            "UPDATE TASK SET Status = ? WHERE Task_ID = ?",
                            (new_status, task_id)
                        )
                        
                        # If completed, update completion date in assignment
                        if success and new_status == 'Completed':
                            execute_non_query(
                                "UPDATE TASK_ASSIGNMENT SET Completion_Date = GETDATE() WHERE Task_ID = ?",
                                (task_id,)
                            )
                        
                        if success:
                            st.session_state.message = f"Task status updated to '{new_status}'!"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
            else:
                st.info("No active tasks to update.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# MAINTENANCE MODULE - NEW
# ============================================================
elif page == "Maintenance":
    st.markdown('<div class="section-header">Maintenance Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4 = st.tabs(["View Requests", "Create Request", "Update Status", "Delete Request"])
    
    with tab1:
        st.subheader("Maintenance Requests")
        
        col1, col2 = st.columns(2)
        with col1:
            status_filter = st.selectbox("Filter by Status", ["All", "Pending", "InProgress", "Completed"])
        with col2:
            priority_filter = st.selectbox("Filter by Priority", ["All", "Critical", "High", "Medium", "Low"])
        
        try:
            query = """
                SELECT 
                    mr.Request_ID,
                    mr.Room_Number,
                    s.First_Name + ' ' + s.Last_Name AS Assigned_To,
                    mr.Description,
                    mr.Request_Date,
                    mr.Priority,
                    mr.Status,
                    mr.Completion_Date
                FROM MAINTENANCE_REQUEST mr
                JOIN STAFF s ON mr.Staff_ID = s.Staff_ID
                WHERE 1=1
            """
            if status_filter != "All":
                query += f" AND mr.Status = '{status_filter}'"
            if priority_filter != "All":
                query += f" AND mr.Priority = '{priority_filter}'"
            query += """
                ORDER BY 
                    CASE mr.Priority 
                        WHEN 'Critical' THEN 1 
                        WHEN 'High' THEN 2 
                        WHEN 'Medium' THEN 3 
                        WHEN 'Low' THEN 4 
                    END,
                    mr.Request_Date DESC
            """
            
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No maintenance requests found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Create Maintenance Request")
        
        try:
            rooms = execute_query("SELECT Room_Number FROM ROOM ORDER BY Room_Number")
            maintenance_staff = execute_query("""
                SELECT Staff_ID, First_Name, Last_Name 
                FROM STAFF 
                WHERE Role = 'Maintenance' AND Status = 'Active'
            """)
            
            if not rooms:
                st.warning("No rooms available.")
            elif not maintenance_staff:
                st.warning("No maintenance staff available.")
            else:
                with st.form("add_maintenance_form", clear_on_submit=True):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        room_options = [r['Room_Number'] for r in rooms]
                        selected_room = st.selectbox("Room Number *", options=room_options)
                        
                        staff_options = {f"{s['First_Name']} {s['Last_Name']}": s['Staff_ID'] for s in maintenance_staff}
                        selected_staff = st.selectbox("Assign To *", options=list(staff_options.keys()))
                    
                    with col2:
                        priority = st.selectbox("Priority *", ["Low", "Medium", "High", "Critical"])
                        status = st.selectbox("Initial Status", ["Pending", "InProgress"])
                    
                    description = st.text_area("Description *")
                    
                    if st.form_submit_button("Create Request"):
                        if not description:
                            st.error("Description is required.")
                        else:
                            staff_id = staff_options[selected_staff]
                            query = """
                                INSERT INTO MAINTENANCE_REQUEST 
                                (Room_Number, Staff_ID, Description, Request_Date, Priority, Status)
                                VALUES (?, ?, ?, GETDATE(), ?, ?)
                            """
                            success, message = execute_non_query(query, (selected_room, staff_id, description, priority, status))
                            if success:
                                st.session_state.message = "Maintenance request created!"
                                st.session_state.message_type = "success"
                                st.rerun()
                            else:
                                st.error(f"Error: {message}")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab3:
        st.subheader("Update Maintenance Status")
        
        try:
            active_requests = execute_query("""
                SELECT mr.Request_ID, mr.Room_Number, mr.Description, mr.Status, mr.Priority
                FROM MAINTENANCE_REQUEST mr
                WHERE mr.Status != 'Completed'
            """)
            
            if active_requests:
                request_options = {f"#{r['Request_ID']} Room {r['Room_Number']}: {r['Description'][:40]}... ({r['Status']})": r for r in active_requests}
                selected = st.selectbox("Select Request", options=list(request_options.keys()))
                
                if selected:
                    request_info = request_options[selected]
                    current_status = request_info['Status']
                    
                    if current_status == 'Pending':
                        new_statuses = ['InProgress', 'Completed']
                    else:
                        new_statuses = ['Completed']
                    
                    new_status = st.selectbox("New Status", new_statuses)
                    
                    if st.button("Update Status"):
                        request_id = request_info['Request_ID']
                        
                        if new_status == 'Completed':
                            query = "UPDATE MAINTENANCE_REQUEST SET Status = ?, Completion_Date = GETDATE() WHERE Request_ID = ?"
                        else:
                            query = "UPDATE MAINTENANCE_REQUEST SET Status = ? WHERE Request_ID = ?"
                        
                        success, message = execute_non_query(query, (new_status, request_id))
                        if success:
                            st.session_state.message = f"Request status updated to '{new_status}'!"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
            else:
                st.info("No active maintenance requests.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Delete Maintenance Request")
        st.warning("Only completed requests should be deleted for record cleanup.")
        
        try:
            requests = execute_query("""
                SELECT mr.Request_ID, mr.Room_Number, mr.Description, mr.Status
                FROM MAINTENANCE_REQUEST mr
                ORDER BY mr.Request_ID DESC
            """)
            
            if requests:
                request_options = {f"#{r['Request_ID']} Room {r['Room_Number']}: {r['Description'][:40]}... ({r['Status']})": r['Request_ID'] for r in requests}
                selected_del = st.selectbox("Select Request to Delete", options=list(request_options.keys()))
                
                confirm = st.checkbox("I confirm I want to delete this request")
                
                if st.button("Delete Request", disabled=not confirm):
                    request_id = request_options[selected_del]
                    success, message = execute_non_query("DELETE FROM MAINTENANCE_REQUEST WHERE Request_ID = ?", (request_id,))
                    if success:
                        st.session_state.message = "Request deleted successfully!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No requests available to delete.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# DISCOUNTS MODULE - NEW
# ============================================================
elif page == "Discounts":
    st.markdown('<div class="section-header">Discount Management</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["View Discounts", "Add Discount", "Update", "Delete", "Apply to Booking"])
    
    with tab1:
        st.subheader("All Discounts")
        try:
            df = pd.DataFrame(execute_query("SELECT * FROM DISCOUNT ORDER BY Valid_From DESC"))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No discounts found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Add New Discount")
        
        with st.form("add_discount_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            
            with col1:
                discount_name = st.text_input("Discount Name *")
                discount_type = st.selectbox("Discount Type *", ["Percentage", "Fixed"])
                discount_value = st.number_input("Discount Value *", min_value=0.01, format="%.2f")
            
            with col2:
                valid_from = st.date_input("Valid From *")
                valid_to = st.date_input("Valid To *")
            
            if st.form_submit_button("Add Discount"):
                if not discount_name:
                    st.error("Discount name is required.")
                elif valid_to < valid_from:
                    st.error("Valid To date must be after Valid From date.")
                else:
                    query = """
                        INSERT INTO DISCOUNT (Discount_Name, Discount_Type, Discount_Value, Valid_From, Valid_To)
                        VALUES (?, ?, ?, ?, ?)
                    """
                    success, message = execute_non_query(query, (discount_name, discount_type, discount_value, valid_from, valid_to))
                    if success:
                        st.session_state.message = f"Discount '{discount_name}' added!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
    
    with tab3:
        st.subheader("Update Discount")
        try:
            discounts = execute_query("SELECT * FROM DISCOUNT ORDER BY Discount_Name")
            if discounts:
                discount_options = {f"{d['Discount_Name']} (ID: {d['Discount_ID']})": d for d in discounts}
                selected = st.selectbox("Select Discount to Update", options=list(discount_options.keys()))
                
                if selected:
                    discount_data = discount_options[selected]
                    
                    with st.form("update_discount_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            new_name = st.text_input("Discount Name", value=discount_data['Discount_Name'])
                            new_type = st.selectbox("Discount Type", ["Percentage", "Fixed"],
                                                   index=["Percentage", "Fixed"].index(discount_data['Discount_Type']))
                            new_value = st.number_input("Discount Value", min_value=0.01, 
                                                       value=float(discount_data['Discount_Value']), format="%.2f")
                        
                        with col2:
                            new_from = st.date_input("Valid From", value=discount_data['Valid_From'])
                            new_to = st.date_input("Valid To", value=discount_data['Valid_To'])
                        
                        if st.form_submit_button("Update Discount"):
                            query = """
                                UPDATE DISCOUNT SET 
                                    Discount_Name=?, Discount_Type=?, Discount_Value=?, Valid_From=?, Valid_To=?
                                WHERE Discount_ID=?
                            """
                            success, message = execute_non_query(query, (new_name, new_type, new_value, new_from, new_to, discount_data['Discount_ID']))
                            if success:
                                st.success("Discount updated!")
                            else:
                                st.error(f"Error: {message}")
            else:
                st.info("No discounts available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Delete Discount")
        st.warning("Discounts applied to bookings cannot be deleted.")
        
        try:
            discounts = execute_query("SELECT Discount_ID, Discount_Name FROM DISCOUNT ORDER BY Discount_Name")
            if discounts:
                discount_options = {f"{d['Discount_Name']} (ID: {d['Discount_ID']})": d['Discount_ID'] for d in discounts}
                selected_del = st.selectbox("Select Discount to Delete", options=list(discount_options.keys()))
                
                confirm = st.checkbox("I confirm I want to delete this discount")
                
                if st.button("Delete Discount", disabled=not confirm):
                    discount_id = discount_options[selected_del]
                    success, message = execute_non_query("DELETE FROM DISCOUNT WHERE Discount_ID = ?", (discount_id,))
                    if success:
                        st.session_state.message = "Discount deleted!"
                        st.session_state.message_type = "success"
                        st.rerun()
                    else:
                        st.error(f"Error: {message}")
            else:
                st.info("No discounts available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab5:
        st.subheader("Apply Discount to Booking")
        
        try:
            # Get active bookings without applied discounts (or allow multiple)
            active_bookings = execute_query("""
                SELECT b.Booking_ID, g.First_Name, g.Last_Name, b.Booking_Rate
                FROM BOOKING b
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                WHERE b.Status IN ('Confirmed', 'CheckedIn')
                ORDER BY b.Booking_ID DESC
            """)
            
            # Get valid discounts (current date within validity period)
            valid_discounts = execute_query("""
                SELECT * FROM DISCOUNT 
                WHERE GETDATE() BETWEEN Valid_From AND Valid_To
                ORDER BY Discount_Name
            """)
            
            if not active_bookings:
                st.warning("No active bookings available.")
            elif not valid_discounts:
                st.warning("No valid discounts available for current date.")
            else:
                with st.form("apply_discount_form", clear_on_submit=True):
                    booking_options = {f"Booking {b['Booking_ID']} - {b['First_Name']} {b['Last_Name']} (${b['Booking_Rate']}/night)": b for b in active_bookings}
                    discount_options = {f"{d['Discount_Name']} ({d['Discount_Type']}: {d['Discount_Value']})": d for d in valid_discounts}
                    
                    selected_booking = st.selectbox("Select Booking *", options=list(booking_options.keys()))
                    selected_discount = st.selectbox("Select Discount *", options=list(discount_options.keys()))
                    
                    if st.form_submit_button("Apply Discount"):
                        booking_info = booking_options[selected_booking]
                        discount_info = discount_options[selected_discount]
                        
                        # Calculate applied value
                        if discount_info['Discount_Type'] == 'Percentage':
                            applied_value = float(booking_info['Booking_Rate']) * (float(discount_info['Discount_Value']) / 100)
                        else:
                            applied_value = float(discount_info['Discount_Value'])
                        
                        query = """
                            INSERT INTO BOOKING_DISCOUNT (Booking_ID, Discount_ID, Applied_Value)
                            VALUES (?, ?, ?)
                        """
                        success, message = execute_non_query(query, (booking_info['Booking_ID'], discount_info['Discount_ID'], applied_value))
                        if success:
                            st.session_state.message = f"Discount applied! Value: ${applied_value:.2f}"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
        except Exception as e:
            st.error(f"Error: {e}")
        
        # Show applied discounts
        st.markdown("---")
        st.markdown("**Applied Discounts**")
        try:
            applied_df = pd.DataFrame(execute_query("""
                SELECT bd.Booking_Discount_ID, bd.Booking_ID, 
                       g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                       d.Discount_Name, bd.Applied_Value
                FROM BOOKING_DISCOUNT bd
                JOIN BOOKING b ON bd.Booking_ID = b.Booking_ID
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                JOIN DISCOUNT d ON bd.Discount_ID = d.Discount_ID
                ORDER BY bd.Booking_Discount_ID DESC
            """))
            if not applied_df.empty:
                st.dataframe(applied_df, use_container_width=True, hide_index=True)
            else:
                st.info("No discounts applied yet.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# PAYMENTS MODULE - IMPROVED
# ============================================================
elif page == "Payments":
    st.markdown('<div class="section-header">Payment Management</div>', unsafe_allow_html=True)
    
    tab1, tab2, tab3, tab4 = st.tabs(["View Payments", "Billing Summary", "Invoices", "Service Transactions"])
    
    with tab1:
        st.subheader("All Payments")
        try:
            query = """
                SELECT 
                    p.Payment_ID,
                    p.Invoice_ID,
                    b.Booking_ID,
                    g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                    p.Payment_Type,
                    p.Amount,
                    p.Payment_Date,
                    p.Payment_Status
                FROM PAYMENT p
                JOIN INVOICE i ON p.Invoice_ID = i.Invoice_ID
                JOIN BOOKING b ON i.Booking_ID = b.Booking_ID
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                ORDER BY p.Payment_Date DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                total_amount = df['Amount'].sum()
                st.info(f"Total Payments: ${total_amount:,.2f}")
            else:
                st.info("No payments found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Billing Summary")
        st.info("View comprehensive billing breakdown for a booking.")
        
        try:
            bookings = execute_query("""
                SELECT b.Booking_ID, g.First_Name, g.Last_Name, b.Status
                FROM BOOKING b
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                WHERE b.Status IN ('CheckedIn', 'CheckedOut')
                ORDER BY b.Booking_ID DESC
            """)
            
            if bookings:
                booking_options = {f"Booking {b['Booking_ID']} - {b['First_Name']} {b['Last_Name']} ({b['Status']})": b['Booking_ID'] for b in bookings}
                selected = st.selectbox("Select Booking", options=list(booking_options.keys()))
                
                if selected:
                    booking_id = booking_options[selected]
                    
                    # Get booking details
                    booking_details = execute_query(f"""
                        SELECT b.*, g.First_Name, g.Last_Name, r.Room_Number, r.Room_Type
                        FROM BOOKING b
                        JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                        LEFT JOIN ROOM_BOOKING_ASSIGNMENT rba ON b.Booking_ID = rba.Booking_ID
                        LEFT JOIN ROOM r ON rba.Room_Number = r.Room_Number
                        WHERE b.Booking_ID = {booking_id}
                    """)[0]
                    
                    # Calculate room charges
                    nights = (booking_details['Check_Out_Date'] - booking_details['Check_In_Date']).days
                    room_charges = float(booking_details['Booking_Rate']) * nights
                    
                    # Get service charges
                    services = execute_query(f"""
                        SELECT s.Service_Name, st.Quantity, st.Total_Amount
                        FROM SERVICE_TRANSACTION st
                        JOIN SERVICE s ON st.Service_ID = s.Service_ID
                        WHERE st.Booking_ID = {booking_id}
                    """)
                    service_total = sum([s['Total_Amount'] for s in services]) if services else 0
                    
                    # Get discounts
                    discounts = execute_query(f"""
                        SELECT d.Discount_Name, bd.Applied_Value
                        FROM BOOKING_DISCOUNT bd
                        JOIN DISCOUNT d ON bd.Discount_ID = d.Discount_ID
                        WHERE bd.Booking_ID = {booking_id}
                    """)
                    discount_total = sum([d['Applied_Value'] for d in discounts]) if discounts else 0
                    
                    # Calculate tax (9%)
                    subtotal = room_charges + service_total - discount_total
                    tax = subtotal * 0.09
                    total = subtotal + tax
                    
                    # Display billing summary
                    st.markdown("---")
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**Guest Information**")
                        st.write(f"Name: {booking_details['First_Name']} {booking_details['Last_Name']}")
                        st.write(f"Room: {booking_details['Room_Number']} ({booking_details['Room_Type']})")
                        st.write(f"Check-In: {booking_details['Check_In_Date']}")
                        st.write(f"Check-Out: {booking_details['Check_Out_Date']}")
                        st.write(f"Nights: {nights}")
                    
                    with col2:
                        st.markdown("**Charges Breakdown**")
                        st.write(f"Room Charges ({nights} nights x ${booking_details['Booking_Rate']}): ${room_charges:.2f}")
                        
                        if services:
                            st.markdown("**Services:**")
                            for s in services:
                                st.write(f"  - {s['Service_Name']} (x{s['Quantity']}): ${s['Total_Amount']:.2f}")
                        st.write(f"Service Total: ${service_total:.2f}")
                        
                        if discounts:
                            st.markdown("**Discounts:**")
                            for d in discounts:
                                st.write(f"  - {d['Discount_Name']}: -${d['Applied_Value']:.2f}")
                        st.write(f"Discount Total: -${discount_total:.2f}")
                        
                        st.markdown("---")
                        st.write(f"Subtotal: ${subtotal:.2f}")
                        st.write(f"Tax (9%): ${tax:.2f}")
                        st.markdown(f"**Total: ${total:.2f}**")
            else:
                st.info("No bookings available for billing.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab3:
        st.subheader("All Invoices")
        try:
            query = """
                SELECT 
                    i.Invoice_ID,
                    i.Booking_ID,
                    g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                    i.Generated_Date,
                    i.Total_Amount
                FROM INVOICE i
                JOIN BOOKING b ON i.Booking_ID = b.Booking_ID
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                ORDER BY i.Invoice_ID DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No invoices found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab4:
        st.subheader("Service Transactions")
        try:
            query = """
                SELECT 
                    st.Transaction_ID,
                    b.Booking_ID,
                    g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                    s.Service_Name,
                    st.Quantity,
                    st.Total_Amount,
                    st.Transaction_Date
                FROM SERVICE_TRANSACTION st
                JOIN BOOKING b ON st.Booking_ID = b.Booking_ID
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                JOIN SERVICE s ON st.Service_ID = s.Service_ID
                ORDER BY st.Transaction_Date DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                total = df['Total_Amount'].sum()
                st.info(f"Total Service Revenue: ${total:,.2f}")
            else:
                st.info("No service transactions found.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# FEEDBACK MODULE - NEW
# ============================================================
elif page == "Feedback":
    st.markdown('<div class="section-header">Guest Feedback</div>', unsafe_allow_html=True)
    
    show_message()
    
    tab1, tab2 = st.tabs(["View Feedback", "Add Feedback"])
    
    with tab1:
        st.subheader("All Feedback")
        try:
            query = """
                SELECT 
                    f.Feedback_ID,
                    b.Booking_ID,
                    g.First_Name + ' ' + g.Last_Name AS Guest_Name,
                    f.Rating,
                    f.Comments,
                    f.Feedback_Date
                FROM FEEDBACK f
                JOIN BOOKING b ON f.Booking_ID = b.Booking_ID
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                ORDER BY f.Feedback_Date DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                avg_rating = df['Rating'].mean()
                st.info(f"Average Rating: {avg_rating:.1f}/5")
            else:
                st.info("No feedback found.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    with tab2:
        st.subheader("Add Guest Feedback")
        
        try:
            # Get bookings that are checked out and don't have feedback yet
            bookings = execute_query("""
                SELECT b.Booking_ID, g.First_Name, g.Last_Name
                FROM BOOKING b
                JOIN GUEST g ON b.Guest_ID = g.Guest_ID
                WHERE b.Status = 'CheckedOut'
                AND b.Booking_ID NOT IN (SELECT Booking_ID FROM FEEDBACK)
                ORDER BY b.Booking_ID DESC
            """)
            
            if bookings:
                with st.form("add_feedback_form", clear_on_submit=True):
                    booking_options = {f"Booking {b['Booking_ID']} - {b['First_Name']} {b['Last_Name']}": b['Booking_ID'] for b in bookings}
                    
                    selected_booking = st.selectbox("Select Booking *", options=list(booking_options.keys()))
                    rating = st.slider("Rating *", min_value=1, max_value=5, value=5)
                    comments = st.text_area("Comments")
                    
                    if st.form_submit_button("Submit Feedback"):
                        booking_id = booking_options[selected_booking]
                        query = """
                            INSERT INTO FEEDBACK (Booking_ID, Rating, Comments, Feedback_Date)
                            VALUES (?, ?, ?, GETDATE())
                        """
                        success, message = execute_non_query(query, (booking_id, rating, comments))
                        if success:
                            st.session_state.message = "Feedback submitted successfully!"
                            st.session_state.message_type = "success"
                            st.rerun()
                        else:
                            st.error(f"Error: {message}")
            else:
                st.info("No checked-out bookings without feedback available.")
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================
# REPORTS MODULE
# ============================================================
elif page == "Reports":
    st.markdown('<div class="section-header">Reports and Analytics</div>', unsafe_allow_html=True)
    
    report_type = st.selectbox("Select Report", [
        "Revenue Report",
        "Room Booking Status",
        "Guest History",
        "Occupancy Report",
        "Maintenance Summary",
        "Staff Performance",
        "Booking Audit Trail"
    ])
    
    if report_type == "Revenue Report":
        st.subheader("Revenue Report")
        try:
            df = pd.DataFrame(execute_query("SELECT * FROM vw_RevenueReport ORDER BY Year DESC, Month DESC"))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                total_revenue = df['Total_Revenue'].sum()
                st.info(f"Total Revenue: ${total_revenue:,.2f}")
            else:
                st.info("No revenue data available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    elif report_type == "Room Booking Status":
        st.subheader("Room Booking Status")
        try:
            df = pd.DataFrame(execute_query("SELECT * FROM vw_RoomBookingStatus ORDER BY Room_Number"))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No data available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    elif report_type == "Guest History":
        st.subheader("Guest History")
        try:
            df = pd.DataFrame(execute_query("SELECT * FROM vw_GuestHistory ORDER BY Total_Spent DESC"))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No guest history available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    elif report_type == "Occupancy Report":
        st.subheader("Occupancy Report")
        try:
            query = """
                SELECT 
                    r.Room_Type,
                    COUNT(*) AS Total_Rooms,
                    SUM(CASE WHEN r.Status = 'Occupied' THEN 1 ELSE 0 END) AS Occupied,
                    SUM(CASE WHEN r.Status = 'Available' THEN 1 ELSE 0 END) AS Available,
                    SUM(CASE WHEN r.Status = 'Maintenance' THEN 1 ELSE 0 END) AS Under_Maintenance,
                    CAST(SUM(CASE WHEN r.Status = 'Occupied' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS Occupancy_Rate
                FROM ROOM r
                GROUP BY r.Room_Type
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No occupancy data available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    elif report_type == "Maintenance Summary":
        st.subheader("Maintenance Summary")
        try:
            query = """
                SELECT 
                    mr.Priority,
                    COUNT(*) AS Total_Requests,
                    SUM(CASE WHEN mr.Status = 'Pending' THEN 1 ELSE 0 END) AS Pending,
                    SUM(CASE WHEN mr.Status = 'InProgress' THEN 1 ELSE 0 END) AS In_Progress,
                    SUM(CASE WHEN mr.Status = 'Completed' THEN 1 ELSE 0 END) AS Completed
                FROM MAINTENANCE_REQUEST mr
                GROUP BY mr.Priority
                ORDER BY 
                    CASE mr.Priority 
                        WHEN 'Critical' THEN 1 
                        WHEN 'High' THEN 2 
                        WHEN 'Medium' THEN 3 
                        WHEN 'Low' THEN 4 
                    END
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No maintenance data available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    elif report_type == "Staff Performance":
        st.subheader("Staff Performance")
        try:
            query = """
                SELECT 
                    s.Staff_ID,
                    s.First_Name + ' ' + s.Last_Name AS Staff_Name,
                    s.Role,
                    s.Status,
                    COUNT(DISTINCT ta.Task_ID) AS Tasks_Assigned,
                    SUM(CASE WHEN t.Status = 'Completed' THEN 1 ELSE 0 END) AS Tasks_Completed,
                    COUNT(DISTINCT mr.Request_ID) AS Maintenance_Handled
                FROM STAFF s
                LEFT JOIN TASK_ASSIGNMENT ta ON s.Staff_ID = ta.Staff_ID
                LEFT JOIN TASK t ON ta.Task_ID = t.Task_ID
                LEFT JOIN MAINTENANCE_REQUEST mr ON s.Staff_ID = mr.Staff_ID
                GROUP BY s.Staff_ID, s.First_Name, s.Last_Name, s.Role, s.Status
                ORDER BY Tasks_Completed DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No staff performance data available.")
        except Exception as e:
            st.error(f"Error: {e}")
    
    elif report_type == "Booking Audit Trail":
        st.subheader("Booking Audit Trail")
        try:
            query = """
                SELECT 
                    Audit_ID,
                    Booking_ID,
                    Action_Type,
                    Action_Date,
                    Action_By,
                    Old_Status,
                    New_Status,
                    Old_CheckIn,
                    New_CheckIn,
                    Old_CheckOut,
                    New_CheckOut
                FROM BOOKING_AUDIT
                ORDER BY Action_Date DESC
            """
            df = pd.DataFrame(execute_query(query))
            if not df.empty:
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info("No audit records found.")
        except Exception as e:
            st.error(f"Error: {e}")

# Footer
st.sidebar.markdown("---")
st.sidebar.text("Hotel Management System")
st.sidebar.text("Version 2.0")