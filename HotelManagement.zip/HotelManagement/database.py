import pyodbc

# Database configuration
DB_CONFIG = {
    'server': 'localhost,1433',
    'database': 'HotelManagementDB',
    'username': 'sa',
    'password': 'shivani@123'
}

def get_connection():
    """Create and return a database connection."""
    conn_string = (
        f"DRIVER={{ODBC Driver 18 for SQL Server}};"
        f"SERVER={DB_CONFIG['server']};"
        f"DATABASE={DB_CONFIG['database']};"
        f"UID={DB_CONFIG['username']};"
        f"PWD={DB_CONFIG['password']};"
        f"TrustServerCertificate=yes"
    )
    return pyodbc.connect(conn_string)

def execute_query(query, params=None):
    """Execute a SELECT query and return results as list of dictionaries."""
    conn = get_connection()
    cursor = conn.cursor()
    if params:
        cursor.execute(query, params)
    else:
        cursor.execute(query)
    columns = [column[0] for column in cursor.description]
    results = [dict(zip(columns, row)) for row in cursor.fetchall()]
    conn.close()
    return results

def execute_non_query(query, params=None):
    """Execute INSERT, UPDATE, DELETE queries."""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        conn.commit()
        return True, "Operation successful"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()